Run `Rscript medical_patient_analysis.R` to generate the PNG output files in this folder.
